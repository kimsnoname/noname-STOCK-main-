import { useState, useEffect } from 'react';
import { Link, Route, Routes, useNavigate } from "react-router-dom";
import { Layout, Spin, Alert, Menu, Modal, Breadcrumb, message, Button, Dropdown, Row, Col, Card, Form, Input, Select, Divider } from 'antd';
import SidebarLayout from './SidebarLayout';
import axios from 'axios';
import './style/transfer.css';

const { Option } = Select;

interface AccountInfo {
  accountNumber: string;
  balance: number;
}

interface AccountPasswordEntity {
  userId: string;
  accountPassword: string;
}

interface TransferEntity {
  userId: string;
  accountPassword: string;
  accountNumber: string;
  amount: Number;
}


const banks = [
  { key: 'bank1', name: '국민은행' },
  { key: 'bank2', name: '기업은행' },
  { key: 'bank3', name: '농협은행' },
  { key: 'bank4', name: '신한은행' },
  { key: 'bank5', name: '산업은행' },
  { key: 'bank6', name: '우리은행' },
  { key: 'bank7', name: '한국씨티은행' },
  { key: 'bank8', name: '하나은행' },
  { key: 'bank9', name: 'SC제일은행' },
  { key: 'bank10', name: '경남은행' },
  { key: 'bank11', name: '새마을금고' },
  { key: 'bank12', name: '수협은행' },
  { key: 'bank13', name: '우체국' },
  { key: 'bank14', name: '카카오뱅크' },
  { key: 'bank15', name: '토스뱅크' },
  { key: 'bank16', name: '케이뱅크' },
];

const Transfer: React.FC = () => {
  const [selectedKey, setSelectedKey] = useState('4'); // 기본으로 내 정보 메뉴 선택
  // const [contentText, setContentText] = useState('계좌 이체 페이지 입니다!'); // 선택된 메뉴에 따른 내용 표시
  // const [accountNumber, setAccountNumber] = useState('');
  // const [balance, setBalance] = useState<number | undefined>(0);
  // const accountNumber = '123456-12';
  // const balance = '300,000';
  const [accountInfo, setAccountInfo] = useState<{ accountNumber: string; balance: number } | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [accountNumber, setAccountNumber] = useState('');
  const [balance, setBalance] = useState('');
  
  var selectedBankKey = '';
  const [transferAmount, setTransferAmount] = useState<number | undefined>(undefined);
  const [selectedBank, setSelectedBank] = useState<string | null>(null);
  const [selectedBankName, setSelectedBankName] = useState<string | null>(null);
  const [selectedAccount, setSelectedAccount] = useState('');
  const [showBankMenu, setShowBankMenu] = useState<boolean>(false);
  const [visible, setVisible] = useState(false);
  const [accountPassword, setAccountPassword] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [userId, setUserId] = useState('');
  const [bankName, setBankName] = useState('');

  useEffect(() => {
    // userId는 실제 애플리케이션에 따라 적절히 설정되어야 합니다.
    const userId = 1;

    axios.get<AccountInfo>(`http://localhost:8080/api/account-info?userId=${userId}`)
        .then(response => {
            setAccountInfo(response.data);
            setLoading(false);
        })
        .catch(error => {
            setError('Failed to fetch account information');
            setLoading(false);
        });
}, []);


  // 은행 클릭 시 작동하는 함수
  const handleBankMenuClick = (bank: any) => {
    setSelectedBank(bank.key);
    setSelectedBankName(bank.name);
  };

  const handleMenuClick = ({ key }) => {
    setSelectedKey(key);
  };

  const handleTransferNext = () => {
    // Perform validation or additional steps if needed
    console.log('Transfer amount:', transferAmount);
  };

  const handleTransfer = () => {
    // Perform transfer logic
    console.log(`Transfering ${transferAmount} to account ${selectedAccount} at bank ${selectedBank}`);
  };

  // 모달 visible 속성 설정
  const showModal = () => {
    setVisible(true);
  };

  const handleCancel = () => {
      setVisible(false);
      setAccountPassword('');
      setAttempts(0);
  };

  const handlePasswordInput = (value: string) => {
    if (accountPassword.length < 6) {
        setAccountPassword(accountPassword + value);
    }
};

  const handleBackspace = () => {
    setAccountPassword(accountPassword.slice(0, -1));
};

  const handlePasswordSubmit = async () => {
    if (accountPassword.length !== 4) {
        message.error('비밀번호는 4자리여야 합니다.');
        return;
    }
    try {
      const response = await axios.post('http://localhost:8080/api/transfer/verifyPassword', {
          userId,
          accountPassword
      });

      if (response.data.success) {
          message.success('비밀번호가 확인되었습니다.');

          const data: TransferEntity = {
            userId,
            accountPassword,
            accountNumber,
            amount: transferAmount,
          };
          
          try {
          const response = await axios.post('http://localhost:8080/api/transfer', data, 
            {
              headers: {
                'Content-Type': 'application/json',
              },
            });
            console.log('이체 성공: ', response.data)
        
            if (response.status === 201) {
              console.log('이체 성공: ', response.data)
              navigate('/transferSuccess', { state: { selectedBankName, selectedAccount, transferAmount }});

            } else {
              console.error(response.status);
              console.error('이체 실패');
            }
          } catch (error) {
            console.error('Error:', error);
          };
  
      } else {
          setAttempts(attempts + 1);
          setAccountPassword('');
          if (attempts + 1 >= 5) {
              message.error('비밀번호를 5회 이상 틀렸습니다. 계좌 이체가 불가능합니다.');
              handleCancel();
          } else {
              message.error('비밀번호가 맞지 않습니다.');
          }
      }
  } catch (error) {
      message.error('서버 오류가 발생했습니다.');
      navigate('/transferSuccess');
      console.error(error);
  }
};

  const handleNextButtonClick = () => {
    if (transferAmount !== undefined && accountInfo) {
      if (transferAmount > accountInfo.balance) {
          setError('이체 금액이 잔액을 초과할 수 없습니다.');
      } else {
          setError(null);
          // 여기서 이체 로직을 추가하세요.
          console.log('이체 진행');
      }
  }
    setShowBankMenu(!showBankMenu);
  };

  // const selectedBankName = selectedBank ? banks.find(bank => bank.key === selectedBank)?.name : banks.find(bank => bank.name);
  
  const bankMenu = (
    <Menu onClick={handleBankMenuClick} >
      <div style={{ width: '400px' }}>
      <Row gutter={[8, 8]} className='bankmenu-button-row'>
        {banks.map((bank) => (
          <Col span={6} key={bank.key}>
            {/* <Button block onClick={() => handleBankMenuClick(bank.key)}> */}
            <Button block className='bankmenu-button' onClick={() => handleBankMenuClick(bank)}>
              {bank.name}
            </Button>
          </Col>
        ))}
      </Row>
      </div>
    </Menu>
  );
  const navigate = useNavigate();
  const handleTransferSuccessRedirect = () => {
    navigate('/transferSuccess', { state: { selectedBankName, selectedAccount, transferAmount }});
  };

  return (
    <SidebarLayout selectedKey={selectedKey} onMenuClick={handleMenuClick}>
      <div className='parent-wrapper-transfer'>
        <div className="wrapper-transfer">
        
          {/* Account Information Card */}
          <Card title="내 계좌 정보" style={{ width: '100%' }}>
            <Row gutter={16}>
              <Col span={8}>
                <Form.Item label="계좌번호">
                  <Input value={accountInfo?.accountNumber} 
                  readOnly />
                </Form.Item>
              </Col>
              <Col span={6}>
              <Form.Item label="계좌 잔액">
                <Input.Group compact>
                  <Input style={{ width: 'calc(100% - 40px)', textAlign: 'right' }} value={accountInfo?.balance.toLocaleString()} readOnly />
                  <Input style={{ width: '40px', textAlign: 'center' }} value="원" readOnly />
                </Input.Group>
              </Form.Item>
              </Col>
            </Row>
          </Card>

          <Divider />

          {/* Transfer Section */}
          <Card title="이체하기" style={{ width: '100%' }}>
            <Form layout="vertical" onFinish={handleTransferNext}>
            <Row gutter={16}>
            <Col span={16}>
              <Form.Item label="이체 금액" >
              <Input.Group compact>
                <Input
                style={{ width: 'calc(100% - 40px)', textAlign: 'right' }}
                  type="number"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(Number(e.target.value))} 
                  />
                <Input style={{ width: '40px', textAlign: 'center' }} value="원" readOnly />
              </Input.Group>
              </Form.Item>
              </Col>
              <Col>
                <Form.Item>
                  <Button type="primary" className='transfer-next-button' onClick={handleNextButtonClick} disabled={!transferAmount}>
                    다음
                  </Button>
                </Form.Item>
              </Col>
              </Row>
              {showBankMenu && (
              <Row gutter={16} className='select-transfer'>
              <Col span={5}>
              <Form.Item label="금융 기관 선택">
                <Input.Group compact>
                  <Input
                    style={{ width: 'calc(100% - 40px)', textAlign: 'right' }}
                    value={[selectedBankName]} readOnly />
                  <Dropdown overlay={bankMenu} trigger={['click']} placement="bottomRight" arrow={{ pointAtCenter: true }}>
                    <Button style={{ width: '40px', textAlign: 'center' }}>
                       ▼ 
                      {/* {selectedBankName ? selectedBankName : '▼'} */}
                    </Button>
                  </Dropdown>
                </Input.Group>
              </Form.Item>
              </Col>
              <Col span={13}>
              <Form.Item label="계좌번호">
                <Input
                  value={selectedAccount}
                  onChange={(e) => setSelectedAccount(e.target.value)} />
              </Form.Item>
              </Col>
              <Col>
              <Form.Item>
                <Button type="primary" className='transfer-button' htmlType="submit" disabled={!selectedAccount} onClick={showModal}>
                  이체
                </Button>
              </Form.Item>
              </Col>
              </Row>
              )}
            </Form>
            <Divider />
          </Card>
          <Modal
                title="비밀번호 입력"
                visible={visible}
                onCancel={handleCancel}
                footer={null}
                width={400} // 모달의 전체 너비 조정
            >
                <div className="modal-content">
                    <div className="password-dots">
                        {Array(4).fill(0).map((_, i) => (
                            <div
                                key={i}
                                className={`password-dot ${i < accountPassword.length ? 'filled' : ''}`}
                            />
                        ))}
                    </div>
                    <Row gutter={[16, 16]} className="button-grid">
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 'Backspace', 0, 'Submit'].map((item, index) => (
                            <Col span={8} key={index}>
                                <Button
                                    type="primary"
                                    block
                                    onClick={() => {
                                        if (item === 'Submit') {
                                            handlePasswordSubmit();
                                        } else if (item === 'Backspace') {
                                            handleBackspace();
                                        } else {
                                            handlePasswordInput(item.toString());
                                        }
                                    }}
                                >
                                    {item}
                                </Button>
                            </Col>
                        ))}
                    </Row>
                </div>
            </Modal>
          </div>
      </div>
    </SidebarLayout>

  );
};

export default Transfer;
