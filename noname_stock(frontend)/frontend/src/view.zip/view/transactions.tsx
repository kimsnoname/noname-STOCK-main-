import { useState } from 'react';
import SidebarLayout from './SidebarLayout';

const Transactions = () => {
  const [selectedKey, setSelectedKey] = useState('3'); // 기본으로 내 정보 메뉴 선택
  const [contentText, setContentText] = useState('거래내역 페이지 입니다!'); // 선택된 메뉴에 따른 내용 표시

  const handleMenuClick = ({ key }) => {
    setSelectedKey(key); // 선택된 메뉴 항목 업데이트
    switch (key) {
      case '1':
        setContentText('내 정보 페이지 입니다!');
        break;
      case '2':
        setContentText('자산 페이지 입니다!');
        break;
      case '3':
        setContentText('거래내역 페이지 입니다!');
        break;
      case '4':
        setContentText('계좌 이체 페이지 입니다!');
        break;
      default:
        setContentText('');
        break;
    }
  };

  return (
    <SidebarLayout 
      selectedKey={selectedKey}
      onMenuClick={handleMenuClick}
      contentText={contentText}
    />
  );
};

export default Transactions;
