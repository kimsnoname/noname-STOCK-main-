// src/components/Register.tsx
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Flex, Form, Checkbox, Button, Input, Row, Col } from 'antd';
import './style/register.css';
import TermsModal from './termsModal';

const Register: React.FC = () => {
  const [email, setEmail] = useState<string>('');
  const [nickname, setNickname] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [emailCode, setEmailCode] = useState<string>('');
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [isEmailVerified, setIsEmailVerified] = useState<boolean>(false);
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [termsVisible, setTermsVisible] = useState(false);
  const [isAgreed, setIsAgreed] = useState(false);
  const [form] = Form.useForm();
  const navigate = useNavigate();

  const handleEmailVerification = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedCode(code);
    alert(`이메일 인증 코드: ${code}`);
    // 실제로는 이메일을 보내는 로직이 여기에 추가되어야 합니다.
  };

  const handleVerifyCode = () => {
    if (emailCode === generatedCode) {
      setIsEmailVerified(true);
      alert('이메일 인증 완료!');
    } else {
      alert('인증 코드가 일치하지 않습니다.');
    }
  };

  // 비밀번호 검증 규칙 함수
  const validatePassword = async (rule: any, value: string) => {
    if (value && value.length >= 8) {
      // 비밀번호가 8글자 이상일 경우 추가 검사
      const regex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]+$/;
      if (regex.test(value)) {
        return Promise.resolve();
      }
    }
    return Promise.reject('비밀번호는 8글자 이상이어야 하며, 영문자, 숫자, 특수문자를 포함해야 합니다.');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEmailVerified) {
        alert('이메일 인증을 완료해 주세요.');
        return;
    }

    if (password !== confirmPassword) {
      alert('비밀번호가 일치하지 않습니다.');
      return;
    }
    // 회원가입 로직을 여기에 추가하세요.
    console.log('회원가입 정보:', { email, nickname, password });
    navigate('/login'); // 회원가입 후 이동할 페이지
  };

  const showTermsModal = () => {
    setTermsVisible(true);
  };

  const handleAgree = () => {
    // setIsAgreed(true);
    setTermsVisible(false);
  };


  return (
    <div className="register-container">
      <Link to="/" className="logo-register">무명증권</Link> {/* Made the logo a clickable link */}
      <h2>회원가입</h2>
      <Form layout="vertical" onFinish={handleSubmit} className="register-form">
      <Flex justify='flex-start' align='center' gap='small'>
        <Form.Item label="이메일" name="email" rules={[{ required: true, message: '이메일을 입력해주세요.' }]}>
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Form.Item>
            <Button type="primary" className="code-button1" onClick={handleEmailVerification} style={{ display: 'block', margin: 'auto' }}>
            인증 코드 받기
            </Button>
        </Flex>

        <Flex justify='flex-start' align='center' gap='small'>
        <Form.Item label="인증 코드" name="emailCode" rules={[{ required: true, message: '인증 코드를 입력해주세요.' }]}>
          <Input type="text" value={emailCode} onChange={(e) => setEmailCode(e.target.value)} />
        </Form.Item>
        <Button type="primary" className="code-button2" onClick={handleVerifyCode} style={{ display: 'block', margin: 'auto' }}>
          인증
        </Button>
        </Flex>
        
        <Form.Item label="닉네임" name="nickname" rules={[{ required: true, message: '닉네임을 입력해주세요.' }]}>
          <Input type="text" value={nickname} onChange={(e) => setNickname(e.target.value)} />
        </Form.Item>
        <Form.Item label="비밀번호" name="password" rules={[
            { required: true, message: '비밀번호를 입력해주세요.' },
            { validator: validatePassword }
            ]}>
          <Input.Password value={password} onChange={(e) => setPassword(e.target.value)} />
        </Form.Item>
        <Form.Item
          label="비밀번호 확인"
          name="confirmPassword"
          dependencies={['password']}
          rules={[
            { required: true, message: '비밀번호 확인을 입력해주세요.' },
            ({ getFieldValue }) => ({
              validator(_, value) {
                if (!value || getFieldValue('password') === value) {
                  return Promise.resolve();
                }
                return Promise.reject(new Error('비밀번호가 일치하지 않습니다.'));
              },
            }),
          ]}
        >
          <Input.Password value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
        </Form.Item>
        <Form.Item
          name="terms"
          valuePropName="checked"
          className="terms-form-item"
          rules={[{ validator: (_, value) => value ? Promise.resolve() : Promise.reject('이용약관에 동의해주세요.') }]}
        >
        <div className="terms-checkbox">
          <Checkbox
            checked={isAgreed}
            onClick={showTermsModal}
          >
            이용약관에 동의합니다
          </Checkbox>
        </div>
        </Form.Item>
          
        <Form.Item>
          <Button type="primary" htmlType="submit" className="register-button" disabled={!isAgreed}>
            <Link to="/welcome">회원가입</Link>
          </Button>
        </Form.Item>
      </Form>
      <TermsModal
        visible={termsVisible}
        onClose={() => setTermsVisible(false)}
        onAgree={handleAgree}
        isAgreed={isAgreed}
        setIsAgreed={setIsAgreed}
        
      />
    </div>
  );
};

export default Register;
