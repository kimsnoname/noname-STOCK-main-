import { useState } from 'react';
import { Link, Route, Routes, useNavigate } from "react-router-dom";
import { Layout, Menu, Breadcrumb, Button, Dropdown, Row, Col, Card, Form, Input, Select, Divider } from 'antd';
import SidebarLayout from './SidebarLayout';
import './style/transfer.css';

const { Option } = Select;


const banks = [
  { key: 'bank1', name: '은행 1' },
  { key: 'bank2', name: '은행 2' },
  { key: 'bank3', name: '은행 3' },
  { key: 'bank4', name: '은행 4' },
  { key: 'bank5', name: '은행 5' },
  { key: 'bank6', name: '은행 6' },
  { key: 'bank7', name: '은행 7' },
  { key: 'bank8', name: '은행 8' },
  { key: 'bank9', name: '은행 9' },
  { key: 'bank10', name: '은행 10' },
  { key: 'bank11', name: '은행 11' },
  { key: 'bank12', name: '은행 12' },
  { key: 'bank13', name: '은행 13' },
  { key: 'bank14', name: '은행 14' },
  { key: 'bank15', name: '은행 15' },
  { key: 'bank16', name: '은행 16' },
];

const Transfer = () => {
  const [selectedKey, setSelectedKey] = useState('4'); // 기본으로 내 정보 메뉴 선택
  // const [contentText, setContentText] = useState('계좌 이체 페이지 입니다!'); // 선택된 메뉴에 따른 내용 표시
  // const [accountNumber, setAccountNumber] = useState('');
  // const [balance, setBalance] = useState<number | undefined>(0);
  const accountNumber = '123456-12'
  const balance = '300,000'
  const [transferAmount, setTransferAmount] = useState('');
  const [selectedBank, setSelectedBank] = useState('');
  const [selectedAccount, setSelectedAccount] = useState('');

  const handleMenuClick = ({ bankKey: string }) => {
    setSelectedBank(bankkey);
  };


  const handleTransferNext = () => {
    // Perform validation or additional steps if needed
    console.log('Transfer amount:', transferAmount);
  };

  const handleTransfer = () => {
    // Perform transfer logic
    console.log(`Transfering ${transferAmount} to account ${selectedAccount} at bank ${selectedBank}`);
  };

  const bankMenu = (
    <Menu>
      <div style={{ width: '200px' }}>
      <Row gutter={[8, 8]}>
        {banks.map((bank) => (
          <Col span={6} key={bank.key}>
            <Button block onClick={() => handleMenuClick(bank.key)}>
              {bank.name}
            </Button>
          </Col>
        ))}
      </Row>
      </div>
    </Menu>
  );

  return (
    <SidebarLayout selectedKey={selectedKey} onMenuClick={handleMenuClick}>
      <div className='parent-wrapper-transfer'>
        <div className="wrapper-transfer">
        
          {/* Account Information Card */}
          <Card title="내 계좌 정보" style={{ width: '100%' }}>
            <Row gutter={16}>
              <Col span={12}>
                <Form.Item label="계좌번호">
                  <Input value={accountNumber} readOnly />
                </Form.Item>
              </Col>
              <Col span={12}>
              <Form.Item label="계좌 잔액">
                <Input.Group compact>
                  <Input style={{ width: 'calc(100% - 40px)', textAlign: 'right' }} value={balance.toLocaleString()} readOnly />
                  <Input style={{ width: '40px', textAlign: 'center' }} value="원" readOnly />
                </Input.Group>
              </Form.Item>
              </Col>
            </Row>
          </Card>

          <Divider />

          {/* Transfer Section */}
          <Card title="이체 하기" style={{ width: '100%' }}>
            <Form layout="vertical" onFinish={handleTransferNext}>
            <Row gutter={16}>
            <Col span={16}>
              <Form.Item label="이체 금액">
              <Input.Group compact>
                <Input
                style={{ width: 'calc(100% - 40px)', textAlign: 'right' }}
                  type="number"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)} />
                <Input style={{ width: '40px', textAlign: 'center' }} value="원" readOnly />
              </Input.Group>
              </Form.Item>
              </Col>
              <Col>
                <Form.Item>
                  <Button type="primary" className='transfer-next-button' htmlType="submit">
                    다음
                  </Button>
                </Form.Item>
              </Col>
              </Row>
              <Row gutter={16}>
              <Col span={8}>
              <Form.Item label="금융 기관 선택">
                {/* <Select value={selectedBank} onChange={(value) => setSelectedBank(value)}>
                  <Option value="bank1">은행 1</Option>
                  <Option value="bank2">은행 2</Option>
                  <Option value="bank3">은행 3</Option>
                </Select> */}
                <Dropdown overlay={bankMenu} trigger={['click']} placement="bottomCenter">
                <Button>
                  {selectedBank ? banks.find(bank => bank.key === selectedBank)?.name : '금융 기관을 선택하세요'} ▼
                </Button>
               </Dropdown>
              </Form.Item>
              </Col>
              <Col span={13}>
              <Form.Item label="계좌번호">
                <Input
                  value={selectedAccount}
                  onChange={(e) => setSelectedAccount(e.target.value)} />
              </Form.Item>
              </Col>
              <Col>
              <Form.Item>
                <Button type="primary" className='transfer-button' htmlType="submit" disabled={!selectedAccount}>
                  이체
                </Button>
              </Form.Item>
              </Col>
              </Row>
            </Form>
            <Divider />
          </Card>
          </div>
      </div>
    </SidebarLayout>

  );
};

export default Transfer;
