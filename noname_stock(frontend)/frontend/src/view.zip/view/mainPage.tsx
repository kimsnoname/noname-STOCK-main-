import { Link, Route, Routes, useNavigate } from "react-router-dom";
import { Button, Menu } from 'antd';
import NewPage from "./newPage";
import GetMyInfo from './getMyInfo';
import Assets from './assets';
import Transactions from './transactions';
import Transfer from './transfer';
import './style/MainPage.css'; // Add this line to import your CSS
import LandingPage from "./landing";
import Login from './loginPage';
import Register from './registerPage';
import Welcome from './welcomePage';
import AccountRegistration from './accountRegistrationPage';


const MainPage =() =>{
    const navigate = useNavigate();
    
    const handleLoginRedirect = () => {
        navigate('/login');
      };
    
    const handleRegisterRedirect = () => {
        navigate('/register');
      };


    const isAuthPage = location.pathname === '/login' || location.pathname === '/register' || location.pathname === '/welcome' || location.pathname === '/accountRegistration';
    return(
        <div>
            {!isAuthPage && (
            <div className="navbar">
            <Link to="/" className="logo">무명증권</Link> {/* Made the logo a clickable link */}
                <Menu mode="horizontal" className="nav-menu">
                <Menu.Item key="trading">
                    <Link to="/trading">트레이딩</Link>
                </Menu.Item>
                <Menu.Item key="GetMyInfo">
                    <Link to="/GetMyInfo">내정보</Link>
                </Menu.Item>
                <Menu.Item key="community">
                    <Link to="/community">종목토론실</Link>
                </Menu.Item>
                <Menu.Item key="notice">
                    <Link to="/notice">공지사항</Link>
                </Menu.Item>
                </Menu>
                <div className="auth-buttons">
                <Button type="primary" onClick={handleRegisterRedirect} className="signup-button">회원가입
                </Button>
                <Button type="default" onClick={handleLoginRedirect} className="login-button">로그인
                </Button>
                </div>
            </div>
            )}
            <Routes>``
                <Route path="/newPage" element={<NewPage />} />
                <Route path="/" element={<LandingPage />} />
                <Route path="/getMyInfo" element={<GetMyInfo />} /> 
                <Route path="/assets" element={<Assets />} /> 
                <Route path="/transactions" element={<Transactions />} /> {/* 추가 */}
                <Route path="/transfer" element={<Transfer />} /> {/* 추가 */}
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/welcome" element={<Welcome />} />
                <Route path="/accountRegistration" element={<AccountRegistration />} />
            </Routes>
            푸터임
        </div>
    )
};


export default MainPage;